package com.example.cs360project2mirandaputnam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

public class LoginActivity extends AppCompatActivity {

    // database instance
    InventoryDatabase inventoryDatabase;

    // view elements
    EditText editTextUsername;
    EditText editTextPassword;

    // button elements
    Button buttonSubmitLogin;
    Button buttonCreateLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_display);

        // instance of the database
        inventoryDatabase = InventoryDatabase.getInstance(this);

        // register elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        buttonSubmitLogin = findViewById(R.id.buttonSubmitLogin);
        buttonCreateLogin = findViewById(R.id.buttonCreateLogin);

        // disable both buttons by default
        buttonSubmitLogin.setEnabled(false);
        buttonCreateLogin.setEnabled(false);

        // listener for text changes
        editTextUsername.addTextChangedListener(textWatcher);
        editTextPassword.addTextChangedListener(textWatcher);
    }

    // text watcher to detect input
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            boolean fieldsAreEmpty = getUsername().isEmpty() || getPassword().isEmpty();
            buttonSubmitLogin.setEnabled(!fieldsAreEmpty);
            buttonCreateLogin.setEnabled(!fieldsAreEmpty);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    // function to log a user in
    public void login(View view) {
            // logs the user in
            boolean isLoggedIn = inventoryDatabase.checkUser(getUsername(), (getPassword()));

            // if login successful, go to inventory list, else show error
            if (isLoggedIn) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.invalid_login));
            }
    }

    // function to register a new user
    public void register(View view) {
        // create a user with given credentials and store in database
        boolean userCreated = inventoryDatabase.addUser(getUsername(), (getPassword()));

            // if user created, log the user in, else show error
            if (userCreated) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.registration_error));
            }
    }

    // bring the user to inventory list
    private void handleLoggedInUser() {
        Intent intent = new Intent(getApplicationContext(), InventoryListActivity.class);
        startActivity(intent);
    }

    // function to get username input
    private String getUsername() {
        Editable username = editTextUsername.getText();
        return username != null ? username.toString().trim().toLowerCase() : "";
    }

    // function to get password input
    private String getPassword() {
        Editable password = editTextPassword.getText();
        return password != null ? password.toString().trim() : "";
    }

    // function to show error with toast message
    private void showError(String errorMessage) {
        Toast toast = Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, -200);
        toast.show();
    }
}