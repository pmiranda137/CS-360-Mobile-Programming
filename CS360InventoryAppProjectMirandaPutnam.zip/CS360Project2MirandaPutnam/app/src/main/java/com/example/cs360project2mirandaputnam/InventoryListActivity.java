package com.example.cs360project2mirandaputnam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class InventoryListActivity extends AppCompatActivity {

    // logcat tag
    private static final String TAG = "InventoryList";

    // inventory item list
    private List<InventoryItem> iItemList;

    // database instance
    InventoryDatabase inventoryDatabase;

    // display elements
    RecyclerView itemListView;
    TextView emptyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // initialize database and list inventory items
        inventoryDatabase = InventoryDatabase.getInstance(getApplicationContext());
        iItemList = inventoryDatabase.getItems();

        // initialize recycler view with grid
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        itemListView = findViewById(R.id.itemListView);
        itemListView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(itemListView.getContext(),
                layoutManager.getOrientation());
        itemListView.addItemDecoration(dividerItemDecoration);

        // view for empty list
        emptyListView = findViewById(R.id.emptyListView);

        // send to recycler view
        ItemAdapter adapter = new ItemAdapter(iItemList, this, inventoryDatabase);
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                checkListIsEmpty();
            }
        });

        itemListView.setAdapter(adapter);

        // check if list is empty
        checkListIsEmpty();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // display app menu
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.action_add_item:
                // "create new item" view
                Log.d(TAG, "New item view");
                intent = new Intent(getApplicationContext(), UpdateItemActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_toggle_notifications:
                // notifications setting screen
                Log.d(TAG, "SMS Notifications view");
                intent = new Intent(getApplicationContext(), NotificationsActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_logout:
                // log user out, back to login screen
                Log.d(TAG, "Logging out");
                intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // function to check if list is empty, toggle display
    public void checkListIsEmpty() {
        Log.d(TAG, "Inventory size: " + iItemList.size());
        if (iItemList.isEmpty()) {
            itemListView.setVisibility(View.GONE);
            emptyListView.setVisibility(View.VISIBLE);
        } else {
            itemListView.setVisibility(View.VISIBLE);
            emptyListView.setVisibility(View.GONE);
        }
    }
}