package com.example.cs360project2mirandaputnam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// function to update item
public class UpdateItemActivity extends AppCompatActivity {

    // name of key to use when sending item to another view
    public static final String EXTRA_ITEM = "com.example.cs360project2mirandaputnam.inventoryitem";

    // database instance
    InventoryDatabase inventoryDatabase;

    // define editText items
    EditText itemName;
    EditText itemQuantity;

    // define action buttons
    Button saveButton;
    Button deleteItemButton;

    // current item
    private InventoryItem mItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // database instance
        inventoryDatabase = InventoryDatabase.getInstance(this);

        // define variables
        itemName = findViewById(R.id.updateItemName);
        itemQuantity = findViewById(R.id.editQuantity_update);
        deleteItemButton = findViewById(R.id.deleteItemButton);
        saveButton = findViewById(R.id.saveItem);

        // initial state of buttons
        deleteItemButton.setVisibility(View.GONE);
        saveButton.setEnabled(false);

        int initialQuantity = 0;

        // see if there was an item passed as serialized data to this view.
        // if so, open it, and set the class item as well as any of the item's values
        InventoryItem item = (InventoryItem) getIntent().getSerializableExtra(EXTRA_ITEM);
        if (item != null) {
            mItem = item;
            itemName.setText(item.getName());
            initialQuantity = item.getQuantity();
            deleteItemButton.setVisibility(View.VISIBLE);
        }

        // set the initial quantity value
        itemQuantity.setText(String.valueOf(initialQuantity));

        // listen to changes to item name or item quantity
        itemName.addTextChangedListener(textWatcher);
        itemQuantity.addTextChangedListener(textWatcher);
    }

    // listen to changes for item name and quantity
    // set save button to enabled or disabled based on text in field
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            saveButton.setEnabled(!getItemName().isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    // function to save item to database
    public void handleSaveItem(View view) {
        boolean saved;

        // existing item, update its values and update database
        if (mItem != null) {
            mItem.setName(getItemName());
            mItem.setQuantity(getItemQuantity());
            saved = inventoryDatabase.updateItem(mItem);
        } else {
            // create new item in database
            saved = inventoryDatabase.addItem(getItemName(), getItemQuantity());
        }

        // if item saved successfully, go back to the previous screen
        // otherwise, display error
        if (saved) {
            NavUtils.navigateUpFromSameTask(this);
        } else {
            Toast.makeText(UpdateItemActivity.this, R.string.save_error, Toast.LENGTH_SHORT).show();
        }
    }

    // function to delete item
    public void handleDeleteItem(View view) {
        // wrap delete action in confirmation dialog
        new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // delete item from database
                        boolean deleted = inventoryDatabase.deleteItem(mItem);
                        finish();

                        // if successfully deleted, go back to the previous screen
                        // otherwise, show error message
                        if (deleted) {
                            NavUtils.navigateUpFromSameTask(UpdateItemActivity.this);
                        } else {
                            Toast.makeText(UpdateItemActivity.this, R.string.delete_error, Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("No", null).show();
    }

    // increment by one
    public void incrementQuantity(View view) {
        itemQuantity.setText(String.valueOf(getItemQuantity() + 1));
    }

    // decrement by one, stop at zero
    public void decrementQuantity(View view) {
        itemQuantity.setText(String.valueOf(Math.max(0, getItemQuantity() - 1)));
    }

    // function to get item name
    private String getItemName() {
        Editable name = itemName.getText();
        return name != null ? name.toString().trim() : "";
    }

    // function to get item quantity
    private int getItemQuantity() {
        String rawValue = itemQuantity.getText().toString().replaceAll("[^\\d.]", "").trim();
        int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

        // quantity can't be less than zero
        return Math.max(quantity, 0);
    }
}