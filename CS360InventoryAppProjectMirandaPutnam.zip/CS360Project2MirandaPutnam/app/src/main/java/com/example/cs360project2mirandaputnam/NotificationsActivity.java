package com.example.cs360project2mirandaputnam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.CompoundButton;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class NotificationsActivity extends AppCompatActivity {

    // logcat tag
    private static final String TAG = "NotificationsActivity";

    // name of the app preference to store whether the user wants to receive notifications or not
    public static String PREFERENCE_RECEIVE_NOTIFICATIONS = "pref_receive_notifications";

    // permissions code
    private final int REQUEST_SEND_SMS_CODE = 0;

    SwitchMaterial notificationsToggle;

    SharedPreferences sharedPrefs;

    boolean receiveNotifications = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        notificationsToggle = findViewById(R.id.notificationsToggle);

        // listen for changes to toggle switch
        notificationsToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                receiveNotifications = isChecked;
                // check for permissions
                if (isChecked && hasPermissions()) {
                    Log.d(TAG, "Wants to receive notifications");
                    notificationsToggle.setChecked(true);
                } else {
                    Log.d(TAG, "Does not want to receive notifications");
                    notificationsToggle.setChecked(false);
                    receiveNotifications = false;
                }

                // update user preferences
                savePreferences();
            }
        });

        // access default shared preferences
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        receiveNotifications = sharedPrefs.getBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, false);

        // initial state of toggle switch based on the permissions and preferences selected
        if (receiveNotifications
                && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
        ) {
            notificationsToggle.setChecked(true);
        }
    }

    // function to check if user has given permission
    private boolean hasPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;

        // if the app doesn't already have permissions
        if (ContextCompat.checkSelfPermission(this, smsPermission)
                != PackageManager.PERMISSION_GRANTED) {

            // check again
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission)) {
                // dialog box to explain permissions
                new AlertDialog.Builder(this)
                        .setTitle(R.string.sms_notification_dialog_title)
                        .setMessage(R.string.sms_notification_justification)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // request permission from user
                                ActivityCompat.requestPermissions(
                                        NotificationsActivity.this,
                                        new String[]{smsPermission},
                                        REQUEST_SEND_SMS_CODE
                                );
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create()
                        .show();
            } else {
                // request permission from user
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{smsPermission},
                        REQUEST_SEND_SMS_CODE
                );
            }
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_SEND_SMS_CODE: {
                // set preferences based on permissions granted
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted message
                    Log.d(TAG, "Permission granted");
                    receiveNotifications = true;
                    notificationsToggle.setChecked(true);
                } else {
                    // permission denied message
                    Log.d(TAG, "Permission denied");
                    receiveNotifications = false;
                    notificationsToggle.setChecked(false);
                }

                // save preferences
                savePreferences();
            }
        }
    }

    // function to save preferences
    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, receiveNotifications);
        editor.commit();
    }
}