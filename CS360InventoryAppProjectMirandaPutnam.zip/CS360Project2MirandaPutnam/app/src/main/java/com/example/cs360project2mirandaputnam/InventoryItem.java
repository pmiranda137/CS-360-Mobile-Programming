package com.example.cs360project2mirandaputnam;

import java.io.Serializable;

public class InventoryItem implements Serializable {
    // define variables
    private long iId;
    private String iName;
    private int iQuantity;

    // default constructor
    public InventoryItem() {
    }

    // constructor for item variables
    public InventoryItem(long id, String name, int quantity) {
        iId = id;
        iName = name;
        iQuantity = quantity;
    }

    // getters and setters
    public long getId() {
        return iId;
    }

    public void setId(long id) {
        this.iId = id;
    }

    public String getName() {
        return iName;
    }

    public void setName(String name) {
        this.iName = name;
    }

    public int getQuantity() {
        return iQuantity;
    }

    // quantity can't be negative
    public void setQuantity(int quantity) {
        this.iQuantity = Math.max(0, quantity);
    }

    // increment quantity
    public void incrementQuantity() {
        this.iQuantity++;
    }

    // decrement quantity, not past zero
    public void decrementQuantity() {
        this.iQuantity = Math.max(0, this.iQuantity - 1);
    }
}